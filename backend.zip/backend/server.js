// server.js
const fs = require('fs');
const express = require('express');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();
const app = express();

// --- CORS ---
app.use(cors({
    origin: "http://localhost:3000",
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    credentials: true
}));

// --- Other middlewares ---
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// --- Database connection ---
const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error('MySQL connection failed:', err);
        process.exit(1);
    }
    console.log('MySQL Connected Successfully');
    seedDummyData(); // Seed sample users & projects
});

// --- File upload configuration ---
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// --- JWT Middleware ---
const verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(403).json({ msg: 'No token' });

    jwt.verify(token, process.env.JWT_SECRET || 'ucu_secret_2025', (err, decoded) => {
        if (err) return res.status(401).json({ msg: 'Invalid token' });
        req.user = decoded;
        next();
    });
};

// === AUTO INSERT SAMPLE DATA ===
function seedDummyData() {
    const users = [
        { username: 'Alex Student', email: 'alex@ucu.ac.ug', password: '123456', role: 'student', faculty: 'Engineering' },
        { username: 'Sarah Student', email: 'sarah@ucu.ac.ug', password: '123456', role: 'student', faculty: 'Business' },
        { username: 'Dr. John', email: 'john@ucu.ac.ug', password: '123456', role: 'supervisor', faculty: 'Engineering' },
        { username: 'Prof. Mary', email: 'mary@ucu.ac.ug', password: '123456', role: 'supervisor', faculty: 'Business' },
        { username: 'Admin UCU', email: 'admin@ucu.ac.ug', password: 'admin123', role: 'admin', faculty: 'Administration' }
    ];

    users.forEach(async (u) => {
        try {
            const hashed = await bcrypt.hash(u.password, 10);
            db.query(
                'INSERT IGNORE INTO users (username, email, password, role, faculty) VALUES (?, ?, ?, ?, ?)',
                [u.username, u.email, hashed, u.role, u.faculty],
                (err) => {
                    if (err) console.error('User insert error:', err);
                    else console.log(`Added/Exists: ${u.username}`);
                }
            );
        } catch (e) {
            console.error('Hashing error:', e);
        }
    });

    // Create uploads directory if missing
    if (!fs.existsSync('uploads')) fs.mkdirSync('uploads', { recursive: true });

    // Sample projects (match your DB columns)
    setTimeout(() => {
        db.query(`INSERT IGNORE INTO projects 
            (title, description, category_id, user_id, status, technologies, document_path, year, faculty, supervisor_comments) VALUES 
            ('Smart Irrigation System', 'IoT-based automated watering system using soil sensors', 1, 1, 'approved', 'Arduino, ESP32, MQTT', 'uploads/sample1.pdf', 2024, 'Engineering', NULL),
            ('UCU Student Portal Mobile App', 'React Native app for checking results and fees', 2, 2, 'approved', 'React Native, Firebase', 'uploads/sample2.pdf', 2025, 'Business', NULL),
            ('AI Chatbot for UCU Admissions', 'GPT-powered assistant for prospective students', 3, 1, 'pending', 'Python, Flask, OpenAI API', 'uploads/sample3.pdf', 2025, 'Engineering', NULL)
        `, (err) => {
            if (err) console.error('Sample projects insert error:', err);
            else console.log("Sample projects added or already exist!");
        });
    }, 2000);
}

// ----------------- API ROUTES -----------------

// Register new user
app.post('/register', async (req, res) => {
    const { username, email, password, role, faculty } = req.body;
    if (!username || !email || !password || !role) return res.status(400).json({ msg: 'Fill all fields' });
    try {
        const hashed = await bcrypt.hash(password, 10);
        db.query('INSERT INTO users (username, email, password, role, faculty) VALUES (?, ?, ?, ?, ?)',
            [username, email, hashed, role, faculty], (err) => {
                if (err) return res.status(500).json({ msg: 'Email already exists or DB error' });
                res.json({ msg: 'Registered successfully!' });
            });
    } catch (e) {
        res.status(500).json({ msg: 'Server error' });
    }
});

// User login
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
        if (err || results.length === 0) return res.status(400).json({ msg: 'User not found' });
        const user = results[0];
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(400).json({ msg: 'Wrong password' });

        const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'ucu_secret_2025', { expiresIn: '24h' });
        res.json({ token, role: user.role, username: user.username });
    });
});

// Submit Project
app.post('/projects', verifyToken, upload.single('document'), (req, res) => {
    if (req.user.role !== 'student') return res.status(403).json({ msg: 'Only students can submit' });

    const { title, description, category_id, technologies, year, faculty } = req.body;
    const document_path = req.file ? req.file.path : null;

    db.query('INSERT INTO projects (title, description, category_id, user_id, status, technologies, document_path, year, faculty) VALUES (?, ?, ?, ?, "pending", ?, ?, ?, ?)',
        [title, description, category_id, req.user.id, technologies, document_path, year, faculty],
        (err) => {
            if (err) return res.status(500).json({ msg: 'Submission failed', error: err });
            res.json({ msg: 'Project submitted for review!' });
        });
});

// Get Pending Projects (for supervisors/admins)
app.get('/projects/pending', verifyToken, (req, res) => {
    if (!['supervisor', 'admin'].includes(req.user.role)) return res.status(403).json({ msg: 'Access denied' });
    db.query('SELECT p.*, u.username FROM projects p JOIN users u ON p.user_id = u.id WHERE status = "pending"', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// Approve/Reject Project
app.put('/projects/:id', verifyToken, (req, res) => {
    if (!['supervisor', 'admin'].includes(req.user.role)) return res.status(403).json({ msg: 'Access denied' });
    const { status, comments } = req.body;
    db.query('UPDATE projects SET status = ?, supervisor_comments = ? WHERE id = ?', [status, comments, req.params.id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ msg: 'Updated!' });
    });
});

// Get Approved Projects (Public)
app.get('/projects/approved', (req, res) => {
    db.query('SELECT p.*, u.username AS student_name FROM projects p JOIN users u ON p.user_id = u.id WHERE status = "approved" ORDER BY created_at DESC', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

// Get Project Details
app.get('/projects/:id', (req, res) => {
    db.query('SELECT p.*, u.username AS student_name FROM projects p JOIN users u ON p.user_id = u.id WHERE p.id = ?', [req.params.id], (err, results) => {
        if (err || results.length === 0) return res.status(404).json({ msg: 'Not found' });
        res.json(results[0]);
    });
});

// Admin Dashboard Analytics
app.get('/analytics', verifyToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ msg: 'Admins only' });
    db.query('SELECT faculty, COUNT(*) AS count FROM projects GROUP BY faculty', (err, facultyData) => {
        if (err) return res.status(500).json(err);
        db.query('SELECT status, COUNT(*) AS count FROM projects GROUP BY status', (err2, statusData) => {
            if (err2) return res.status(500).json(err2);
            res.json({ projectsPerFaculty: facultyData, approvalRates: statusData });
        });
    });
});

// Get Categories
app.get('/categories', (req, res) => {
    db.query('SELECT * FROM categories', (err, results) => {
        if (err) return res.status(500).json([]);
        res.json(results || []);
    });
});

// --- Start server ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`API available at http://localhost:${PORT}`);
});

module.exports = app;
